# ionic-service-push-client
Client-side code for the ionic push service
