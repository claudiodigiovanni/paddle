#import "IonicConstant.h"

NSString *const NO_DEPLOY_LABEL = @"NO_DEPLOY_LABEL";
NSString *const NOTHING_TO_IGNORE = @"NOTHING_TO_IGNORE";
